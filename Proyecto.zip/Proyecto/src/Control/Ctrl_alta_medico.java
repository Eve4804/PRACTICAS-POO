package Control;

import Base_datos.BD_alta_medico;
import Base_datos.File_alta_medico;
import java.util.regex.Pattern;
import java.io.*;

/**
 *
 * @author kike
 */
public class Ctrl_alta_medico {

    public Ctrl_alta_medico() {
    }

    public int[] getValidarInfo(String ced, String nom, String ap,
            String am, String nc, String inst, String he, String hs) {
        /* El VECTOR QUE REGRESA ESTA FUNCION, TENDRA ESTO:
         [0]: SI HUBO UN ERROR Y EL TIPO DE ERROR CODIFICADO EN NUMEROS
         [1]: HACE REFERENCIA AL ELEMENTO GRAFICO QUE TIENE ESE ERROR*/
        int[] ok = new int[2];
        ok[0] = 0;
        ok[1] = 0;

        //VALIDAR LA CEDULA
        ok[0] = this.validarNumero(ced);
        ok[1] = 1; // CEDULA
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        //VALIDAR NOMBRE
        ok[0] = this.validarString(nom);
        ok[1] = 2; // NOMBRE
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        //VALIDAR APELLIDO PATERNO
        ok[0] = this.validarString(ap);
        ok[1] = 3; // APELLIDO PATERN
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        //VALIDAR APELLIDO MATERNO
        ok[0] = this.validarString(am);
        ok[1] = 4; // APELLIDO MATERNO
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        //VALIDAR LA INSTITUCION
        if (inst.compareTo("--- SELECCIONE ---") == 0) {
            ok[0] = 1; //ERROR: DEBES DE SELECCIONAR AL MENOS UNA OPCION
        } else {
            ok[0] = 0;  //NO HUBO ERRORES
        }
        ok[1] = 5;  //INSTITUCION
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        //VALIDAR HORA DE ENTRADA
        ok[0] = this.getValidaHora(he);
        ok[1] = 6; // HORA DE ENTRADA
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        //VALIDAR HORA DE SALIDA
        ok[0] = this.getValidaHora(hs);
        ok[1] = 7; // HORA DE SALIDA
        if (ok[0] != 0) //SI HAY ERRORES
        {
            return ok;
        }

        /// CODIGO PARA CONECTARNOS HACIA ACCESS
       /* if (ok[0] == 0) {
            //CONECTAR A NUESTRA BASE DE DATOS
            BD_alta_medico objMed = new BD_alta_medico();
            ok[1] = 8; //SI EXISTE ERROR EN LA BASE DE DATOS
            ok[0] = objMed.setAltaMedico(ced, ap, am, nom, nc, inst, he, hs);
        }*/

        /// CODIGO PARA CREAR UN ARCHIVO DE TEXTO
        if (ok[0] == 0) {
            ok[1] = 9; //SI HAY UN ERROR EN EL ARCHIVO
            try {
                //AQUI SE VA A ENVIAR LOS DATOS PARA QUE SE GUARDEN
                File_alta_medico objF = new File_alta_medico();
                ok[0] = objF.getAltaMedico(ced, ap, am, nom, nc, inst, he, hs);
            } catch (IOException e) {
                ok[0] = 3; //ERROR: NO EXISTE EL ARCHIVO
            }

        }
        return ok;
    }

    private int getValidaHora(String txt) {
        /* HORAS PERMITIDAS O CORRECTAS O VALIDAS:
           3:19    03:25   11:50am  1:09pm 2:54P.M. */
        String patron;
        int x = 0, k = 0;
        patron = "^(?:0?[1-9]|1[0-2]):[0-5][0-9]\\s?(?:[APap](\\.?)[Mm]\\1)?$";

        if (txt.length() != 0) {
            if (Pattern.compile(patron).matcher(txt).matches()) {
                k++;
            }
        } else {
            return 1; //ERROR: NO DEBE DE ESTAR VACIO EL CAMPO
        }
        x++;

        if (k == x) {
            return 0; //NO HAY ERRORES
        } else {
            return 2; //ERROR: EL FORMATO ES INCORRECTO
        }
    }

    private int validarString(String txt) {
        /*expresion regular, patron ^[A-Z][a-zÀ-ÿÑñ]+$
     ^ ---> inicio    $--> fin
      \s  --> espacio    
        txt = "Juan CarloS"
        r = ["Juan", "CarloS"]  longitud = 2*/
        String[] r;
        int x = 0, k = 0;
        r = txt.split("\\s");
        while (x < r.length) {
            if (r[x].length() != 0) {
                //HAY ALGO
                if (Pattern.compile("^[A-Z][a-zÀ-ÿÑñ]+$").matcher(r[x]).matches()) {
                    k++;
                }
            } else {
                return 1; //ERROR: NO DEBE ESTAR VACIO
            }
            x++;
        }

        if (k == x) {
            return 0; //NO HAY ERRORES
        } else {
            return 2; //ERROR: DEBES DE TECLEAR SOLO LETRAS  
        }
    }

    private int validarNumero(String ced) {
        int c = 0, g;

        if (ced.length() == 0) {
            return 1; //ERROR: DEBES DE LLENAR EL CAMPO
        } else {
            //SI HAY ALGO
            if (ced.length() >= 7 && ced.length() <= 10) {
                for (g = 0; g < ced.length(); g++) {
                    if (ced.charAt(g) >= '0' && ced.charAt(g) <= '9') {
                        c++;
                    }
                }
                if (c == ced.length()) {
                    return 0; // NO HAY ERRORES
                } else {
                    return 3; //ERROR: VERIFICA QUE SEAN NUMEROS              
                }
            } else {
                return 2; // ERROR: VERIFICA QUE SEAN DE 7 A 10 NUMEROS
            }
        }
    }

    public String[][] getInfo() {
        BD_alta_medico query = new BD_alta_medico();
        return query.getInfo();
    }

    public String[][] getInfoFile() {
        try {
            File_alta_medico objF = new File_alta_medico();
            return objF.getInfo();
        } catch (IOException e) {
            return null;
        }

    }

}
