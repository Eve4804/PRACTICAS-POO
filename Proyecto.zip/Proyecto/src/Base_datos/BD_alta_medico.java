package Base_datos;

import java.sql.*;

/**
 *
 * @author kike
 */
public class BD_alta_medico {

    Connection conn = null;

    private Connection setConn() {
        String cad;
        try {
            cad = "jdbc:ucanaccess://test.accdb";
            this.conn = DriverManager.getConnection(cad);
            return this.conn;
        } catch (SQLException e) {
            return null;
        }
    }

    private void closeConn() {
        try {
            this.conn.close();
            this.conn = null;
        } catch (SQLException e) {

        }
    }

    public int setAltaMedico(String ced, String ap, String am,
            String nom, String nc, String inst, String he, String hs) {
        //PASO 1: CONECTARNOS A LA BASE
        this.conn = this.setConn(); // conn de la base o null
        //boolean existe;
        if (this.conn != null) {
            //correcta
            //existe = this.existDat(ced);
            if (this.existDat(ced) == false) {
                //se inserta
                if (this.setInserta(ced, ap, am, nom, nc, inst, he, hs) == true) {
                    return 1; // se guardo correctamente,al médico
                }
            } else {
                return 3; //error: ya existe la info en la base
            }
            this.closeConn();//cerrar conexion
        } else {
            return 2; //error: no pudo conectarse a la base
        }
        return 0;
    }

    private boolean existDat(String ced) {
        /*
        Para Java, en especifico JDBC, las sentecias SQL se ejecutan mediante el 
        proceso executeQuery --> SELECT
        Para las sentencias de insertar datos, actualizar datos, borrar datos
        se utiliza el proceso executeUpdate --> INSERT, UPDATE, DELETE
        -------------
        SELECT COUNT(*)
        FROM medico
        WHERE cedula = ?;
                                    1  */
        String sql;
        sql = "SELECT COUNT(*) FROM medico WHERE  cedula = ?;";
        try {
            PreparedStatement ps;
            ResultSet rs;
            ps = this.conn.prepareStatement(sql);
            ps.setString(1, ced);
            rs = ps.executeQuery();
            if (rs.next()) {
                if (rs.getInt(1) != 0) {
                    rs.close();
                    return true; //si existe
                }
            }

        } catch (SQLException er) {
            return false; //no existe
        }

        return false;//no existe
    }

    private boolean setInserta(String ced, String ap, String am,
            String nom, String nc, String inst, String he, String hs) {
        PreparedStatement ps;
        String sql = "INSERT INTO medico VALUES(?,?, ?, ?, ?, ?,?, ?, ? );";
        try {
            ps = this.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, ps.getMaxRows());
            ps.setString(2, ced);
            ps.setString(3, ap);
            ps.setString(4, am);
            ps.setString(5, nom);
            ps.setString(6, inst);
            ps.setString(7, he);
            ps.setString(8, hs);
            ps.setInt(9, Integer.parseInt(nc));
            // Integer.parseInt(String) --> convierte de String a entero (int)  

            if (ps.executeUpdate() > 0) {
                return true; //si se inserto
            }
        } catch (SQLException e) {
            return false;
        }
        return false;
    }

    public String[][] getInfo() {
        /*{ "Cédula", "Nombre", "Ap. Paterno", "Ap. Materno", "Institución", 
        "Consultorio", "Hora de Entrada","Hora de Salida"};*/
        String sql;
        ResultSet rs;
        Statement s;
        String[][] dat = null;
        int f = 0, k = 0;
        try {
            sql = "SELECT cedula, nombre, appat, apmat, institu, num,hent, hsal ";
            sql += "FROM medico ORDER BY nombre ASC;";

            this.conn = this.setConn();
            if (this.conn != null) {
                s = this.conn.createStatement();
                rs = s.executeQuery(sql);
                while (rs.next()) {
                    f++;
                }
                rs.close();
                if (f > 0) {
                    //creo la matriz
                    dat = new String[f][8];
                    rs = s.executeQuery(sql);
                    while (rs.next()) {
                        //llenar la matriz con los datos
                        dat[k][0] = rs.getString("cedula");
                        dat[k][1] = rs.getString("nombre");
                        dat[k][2] = rs.getString("appat");
                        dat[k][3] = rs.getString("apmat");
                        dat[k][4] = rs.getString("institu");
                        dat[k][5] = rs.getString("num");
                        dat[k][6] = rs.getString("hent");
                        dat[k][7] = rs.getString("hsal");
                        k++;
                    }
                    rs.close();
                    this.closeConn();
                }

            }

        } catch (SQLException e) {
            return null;

        }
        return dat;
    }

}
