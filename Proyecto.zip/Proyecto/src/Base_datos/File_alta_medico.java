package Base_datos;
import java.io.*;

/**
 * @author kike
 */
public class File_alta_medico {
    //declarar variables para el uso del archivo

    private RandomAccessFile raf; //archivo
    private int tamReg = 140;  //tamaño del registro en bytes
    private int nReg;

    public int getAltaMedico(String ced, String ap, String am,
            String nom, String nc, String inst, String he, String hs) throws IOException {
        //Creamos el archivo y verificamos si existe o no
        File med = new File("lstMedico.dat");
        if (med.exists() && !med.isFile()) {
            return 2;//ERROR: NO EXISTE EL ARCHIVO
        }

        //abrir el archivo con un tipo de acceso (r o rw)
        this.raf = new RandomAccessFile(med, "rw");
        //cuantos elementos tengo en mi archivo
        this.nReg = (int) Math.ceil((double) this.raf.length() / (double) this.tamReg);
        this.raf.seek(this.nReg * this.tamReg);
        //Guardamos los datos
        this.raf.writeUTF(ced);
        this.raf.writeUTF(nom);
        this.raf.writeUTF(ap);
        this.raf.writeUTF(am);
        this.raf.writeUTF(inst);
        this.raf.writeUTF(nc);
        this.raf.writeUTF(he);
        this.raf.writeUTF(hs);
        //cerrarlo
        this.raf.close();
        return 1; //NO HUBO ERRORES
    }

    public String[][] getInfo() throws IOException {
        String[][] dat;
        File med = new File("lstMedico.dat");
        if (med.exists() && !med.isFile()) {
            return null;
        }

        //abrir el archivo con un tipo de acceso (r o rw)
        this.raf = new RandomAccessFile(med, "r");
        //cuantos elementos tengo en mi archivo
        this.nReg = (int) Math.ceil((double) this.raf.length() / (double) this.tamReg);
        dat = new String[this.nReg][8];
        try {
            for (int x = 0; x < this.nReg; x++) {
                this.raf.seek(x * this.tamReg);
                dat[x][0] = this.raf.readUTF();
                dat[x][1] = this.raf.readUTF();
                dat[x][2] = this.raf.readUTF();
                dat[x][3] = this.raf.readUTF();
                dat[x][4] = this.raf.readUTF();
                dat[x][5] = this.raf.readUTF();
                dat[x][6] = this.raf.readUTF();
                dat[x][7] = this.raf.readUTF();
            }
        } catch (EOFException e) {
            return null; 
        } finally {
            if (this.raf != null) {
                this.raf.close();//cerrar archivo
            }
        }
        return dat;
    }

}
